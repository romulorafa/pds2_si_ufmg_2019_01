#include "rainha.h"

Rainha::Rainha(int x, int y) {
    
}